#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
const int maxn=1e5;
const LL h=1e9+9;

int A[maxn+5];
int point[maxn+5];
int T[maxn+5];
LL bit[maxn+5];

map<int,int> mapx;

int sum(int i)
{
	LL s=0;
	while (i>0)
	{
		s+=bit[i];
		i-=i&(-i);
	}
	return s%h;
}

void add(int i,LL x,int n)
{
	while (i<=n)
	{
		bit[i]=(bit[i]+x+h)%h;
		i+=i&(-i);
	}
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,k;
	scanf("%d%d",&n,&k);
	
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&A[i]);
		point[i]=A[i];
	}
	
	memset(T,0,sizeof(T));
	memset(bit,0,sizeof(bit));
	
	sort(point+1,point+1+n);
	
	for (int i=1;i<=n;++i)
	{
		if (!mapx.count(A[i]))
		{
			mapx[A[i]]=0;
		}
		else
		{
			mapx[A[i]]=mapx[A[i]]+1;
		}
		int l=lower_bound(point+1,point+1+n,A[i]-k)-point-1;
		//int r=lower_bound(point+1,point+1+n,A[i]+k)-point;
		int r=upper_bound(point+1,point+1+n,A[i]+k)-point-1;
		int s=lower_bound(point+1,point+1+n,A[i])-point+mapx[A[i]];
		
		int t=(sum(r)-sum(l)+h)%h;
		//cout<<t<<endl;
		if (t==0)
		{
			add(s,1,n);
			T[s]=1;
		}
		else
		{
			add(s,t-T[s]+1,n);
			T[s]=t+1;
		}
	}
	
	LL ans=sum(n);
	
	ans=(ans-n+h)%h;
	printf("%lld\n",ans);
	
	#ifdef ex1
	for (int i=1;i<=n;++i)
	{
		printf("%d ",T[i]);
	}
	for (int i=1;i<=n;++i)
	{
		printf("%d ",bit[i]);
	}
	#endif
	
}
