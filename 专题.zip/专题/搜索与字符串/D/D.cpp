#include<bits/stdc++.h>

#define clr(x) memset(x,0,sizeof(x))

using namespace std;
typedef long long LL;

const int maxn=5e4;

struct edge{int to,cost;};

vector <edge> G[maxn+5];
int opr[maxn+5];
int vis[maxn+5];

bool dfs(int x,int op,int &cnt)
{
    cnt+=op;
    ++vis[x];
    opr[x]=op;

    for (int i=0;i<G[x].size();++i)
    {
        int to=G[x][i].to;
        int w=G[x][i].cost;

        if (vis[to]==vis[x])
        {
            if (opr[x]^opr[to]^w) return false;
        }
        else
        {
            int t=w^opr[x];
            if (!dfs(to,t,cnt)) return false;
        }
    }

    return true;
}

int main(void)
{
	#ifdef ex
	freopen ("../in.txt","r",stdin);
	//freopen ("../out.txt","w",stdout);
	#endif

	int n,m;
	scanf("%d%d",&n,&m);

	int u,v,w;
	for (int i=1;i<=m;++i)
    {
        scanf("%d%d%d",&u,&v,&w);
        G[u].push_back((edge){v,w});
        G[v].push_back((edge){u,w});
    }

    memset(vis,0,sizeof(vis));

    int ans=0;
    for (int i=1;i<=n;++i)
    {
        if (vis[i]==0)
        {
            int t1=0;
            int t2=0;
            if (!dfs(i,0,t1) || !dfs(i,1,t2))
            {
                printf("Pan must forget something.\n");
                return 0;
            }
            else
            {
                ans+=min(t1,t2);
            }
        }
    }

    printf("%d\n",ans);
}
