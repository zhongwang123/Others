#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

int A[9]={1,2,3,4,5,6,7,8,9};
int ans[1000][10];

void check(int A[],int &tot)
{
	int ok=1;
	for (int i=1;i<=8;++i)
	{
		for (int j=0;j<i;++j)
		{
			if (abs(A[i]-A[j])==i-j)
			{
				ok=0;
				break;
			}
		}
		if (!ok)
		{
			break;
		}
	}
	
	if (ok)
	{
		++tot;
		for (int i=0;i<=8;++i)
		{
			ans[tot][i]=A[i];
		}
	}
}

int main(void)
{
	#ifdef ex
	//freopen ("in.txt","r",stdin);
	freopen ("1.txt","w",stdout);
	#endif
	int n;
	scanf("%d",&n);
	
	int tot=0;
	do
	{
		check(A,tot);
	}
	while (next_permutation(A,A+9));
	
	printf("%d\n",tot);
	for (int i=1;i<=tot;++i)
	{
		for (int j=0;j<=8;++j)
		{
			printf("%d ",ans[i][j]);
		}
		printf("\n");
	}
	
}
