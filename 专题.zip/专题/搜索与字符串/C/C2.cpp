#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=1e6;

int st[maxn+5][9];
int ans[maxn+5];
int query[9];
int goal[9]={1,2,3,4,5,6,7,8,0};
int dist[maxn+5];

int dx[]={-1,1,0,0};
int dy[]={0,0,-1,1};

bool vis[362880];
int factor[9];


int Code(int s[])
{
	int code=0;
	for (int i=0;i<=8;++i)
	{
		int cnt=0;
		for (int j=i+1;j<=8;++j)
		{
			if (s[j]<s[i]) ++cnt;
		}
		code+=factor[8-i]*cnt;
	}
	return code;
}

void bfs()
{
	int head=1;
	int tail=2;

	int code=Code(st[1]);
	ans[code]=0;
	vis[code]=true;

	while (head<tail)
	{
		int z;
		for (z=0;z<9;++z)
		{
			if (!st[head][z]) break;
		}
		int x=z/3;
		int y=z%3;
		for (int i=0;i<=3;++i)
		{
			int nx=x+dx[i];
			int ny=y+dy[i];
			int nz=nx*3+ny;
			if (nx>=0 && nx<=2 && ny>=0 && ny<=2)
			{
				memcpy(&st[tail],&st[head],sizeof(st[head]));
				st[tail][nz]=st[head][z];
				st[tail][z]=st[head][nz];
				dist[tail]=dist[head]+1;

				int code=Code(st[tail]);
				//cout<<code<<endl;
				if (!vis[code])
				{
					vis[code]=true;
					ans[code]=dist[tail];
					++tail;
				}
			}
		}
		++head;
	}

}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	//freopen ("1.txt","w",stdout);
	#endif

	factor[0]=1;
	for (int i=1;i<=8;++i)
	{
		factor[i]=factor[i-1]*i;
	}
	memset(ans,-1,sizeof(ans));
	memset(vis,0,sizeof(vis));

	memcpy(&st[1],&goal,sizeof(goal));
	bfs();

	int T;
	scanf("%d",&T);

	for (int k=1;k<=T;++k)
	{
		char ss[5];
		for (int i=0;i<=8;++i)
		{
			scanf("%s",ss);
			if (ss[0]=='x')
			{
				query[i]=0;
			}
			else
			{
				query[i]=ss[0]-'0';
			}
		}

		int code=Code(query);
		//cout<<code<<endl;
	    printf("%d\n",ans[code]);
	}

}
