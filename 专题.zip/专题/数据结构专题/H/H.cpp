#include<bits/stdc++.h>

using namespace std;
const int maxn=1e6;
typedef struct S S;

struct S 
{
	int id;
	int v;
};

map<int,int> Xmax;
map<int,int> Ymax;

S p[maxn+5];
int par[maxn+5];
int fx[maxn+5];
int fy[maxn+5];
int ans[maxn+5];

bool cmp(const S &a,const S &b)
{
	return a.v<b.v;
}

int find(int x)
{
	if (par[x]==x) return x;
	else
	{
		return par[x]=find(par[x]);
	}
}

void unite(int x,int y)
{
	int px=find(x),py=find(y);
	if (px==py) return;
	else
	{
		par[px]=py;
	}
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	freopen ("2.txt","w",stdout);
	#endif
	
	int n,m;
	scanf("%d%d",&n,&m);
	
	int Size=n*m;
	
	for (int i=0;i<=Size-1;++i)
	{
		scanf("%d",&p[i].v);
		p[i].id=i;
		par[i]=i;
	}
	
	sort(p,p+Size,cmp);
	
	int s=0;
	for (int i=0;i<=Size-1;++i)
	{
		if (i!=Size-1 && p[i].v==p[i+1].v) continue;
		for (int j=s;j<=i;++j)
		{
			int id=p[j].id;
			int x=id%m;
			int y=id/m;
			fx[x]=id;
			fy[y]=id;
		}
		for (int j=s;j<=i;++j)
		{
			int id=p[j].id;
			int x=id%m;
			int y=id/m;
			unite(id,fx[x]);
			unite(id,fy[y]);
			
		}
		
		for (int j=s;j<=i;++j)
		{
			int id=p[j].id;
			int x=id%m;
			int y=id/m;
			int r=find(id);
			ans[r]=max(ans[r],max(Xmax[x],Ymax[y])+1);
		}
		
		for (int j=s;j<=i;++j)
		{
			int id=p[j].id;
			int x=id%m;
			int y=id/m;
			int r=find(id);
			Xmax[x]=ans[r];
			Ymax[y]=ans[r];
		}
		
		s=i+1;
		
	}
	
	
	for (int i=0;i<=n-1;++i)
	{
		for (int j=0;j<=m-1;++j)
		{
			int k=find(i*m+j);
			printf("%d ",ans[k]);
		}
		printf("\n");
	}

}
