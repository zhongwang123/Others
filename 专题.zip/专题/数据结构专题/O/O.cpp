#include<bits/stdc++.h>

using namespace std;
const int maxn=1e6;
const int SIZE=1<<22;
const int h=772002+233;
typedef long long LL;
typedef struct seg_tree seg_tree;

struct seg_tree
{
	int num;
	LL x;
};

seg_tree T[SIZE];
int arr[maxn+5];

int tree_size(int n)
{
	int k=1;
	while (k<n)
	{
		k<<=1;
	}
	return k;
}

void update(int k,int cl,int cr,int l,int r,int p)
{
	if (cl>r || cr<l) return;
	if (l<=cl && cr<=r)
	{
		++T[k].num;
		T[k].x+=(p-(cl-l));
	}
	else
	{
		int mid=(cl+cr)>>1;
		update(k<<1,cl,mid,l,r,p);
		update((k<<1)+1,mid+1,cr,l,r,p);
	}
}

int query(int k,int cl,int cr,int x)
{
	int t=0;
	if (T[k].num)
	{
		t=(T[k].x-T[k].num*(LL)(x-cl))%h;
	}
	
	if (cl==cr)
	{
		return t;
	}
	int mid=(cl+cr)>>1;
	if (x<=mid)
	{
		return (query(k<<1,cl,mid,x)+t)%h;
	}
	else
	{
		return (query((k<<1)+1,mid+1,cr,x)+t)%h;
	}
}
int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,q;
	scanf("%d%d",&n,&q);
	
	int Tsize=tree_size(n);
	
	LL xx;
	for (int i=1;i<=n;++i)
	{
		scanf("%lld",&xx);
		xx%=h;
		arr[i]=xx;
	}
	
	int op,x,y;
	for (int i=1;i<=q;++i)
	{
		scanf("%d",&op);
		if (op==1)
		{
			scanf("%d%d",&x,&y);
			int rx=min(x+y-1,Tsize);
			update(1,1,Tsize,x,rx,y);
		}
		else
		{
			scanf("%d",&x);
			int ans=(query(1,1,Tsize,x)+arr[x])%h;
			printf("%d\n",ans);
		}
	}
}

