#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
const int maxn=1e5;
typedef struct P P;

struct P
{
	int t;
	int l;
	int r;
};

int T[8*maxn];
int S[4*maxn+5];
set <int> s;
int point[2*maxn+5];
P op[maxn+5];

int tree_size(int n)
{
	int k=1;
	while (k<n)
	{
		k<<=1;
	}
	return k;
}

void cover(int k,int cl,int cr,int l,int r)
{
	if (T[k]==1) return;
	if (cl>r || cr<l) return;
	if (l<=cl && cr<=r)
	{
		T[k]=1;
		return;
	}
	else
	{
		int mid=(cl+cr)>>1;
		cover(k<<1,cl,mid,l,r);
		cover((k<<1)+1,mid+1,cr,l,r);
		if (l<=mid && mid+1<=r) S[k]=1;
	}
}

int query(int k,int cl,int cr,int l,int r)
{
	//cout<<1<<endl;
	if (cl==cr && T[k]==0)
	{
		return 0;
	}
	else if (cl>r || cr<l) return 0;
	else if (T[k]==1)
	{
		int tl=max(cl,l);
		int tr=min(cr,r);
		return point[tr]-point[tl]+1;
	}
	else
	{
		int mid=(cl+cr)>>1;
		int res=query(k<<1,cl,mid,l,r)+query((k<<1)+1,mid+1,cr,l,r);
		if (S[k]==1 && l<=mid && mid+1<=r) 
		{
			//cout<<res<<endl;
			res+=point[mid+1]-point[mid]-1;
			//cout<<res<<endl;
		}
		return res;
	}
}
int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,q,t,l,r;
	scanf("%d%d",&n,&q);
	
	
	for (int i=1;i<=q;++i)
	{
		scanf("%d%d%d",&t,&l,&r);
		{
			if (!s.count(l)) s.insert(l);
			if (!s.count(r)) s.insert(r);
			op[i]=(P){t,l,r};
		}
	}
	
	int num=0;
	for (set<int> ::iterator it=s.begin();it!=s.end();it++)
	{
		point[++num]=*it;
	}
	int Tsize=tree_size(num);
	for (int i=1;i<=q;++i)
	{
		int tx=op[i].t;
		int l=op[i].l;
		int r=op[i].r;
		if (tx==1)
		{
			int lx=lower_bound(point+1,point+num+1,l)-point;
			int rx=lower_bound(point+1,point+num+1,r)-point;
			cover(1,1,Tsize,lx,rx);
		}
		else
		{
			int lx=lower_bound(point+1,point+num+1,l)-point;
			int rx=lower_bound(point+1,point+num+1,r)-point;
			int ans=point[rx]-point[lx]+1-query(1,1,Tsize,lx,rx);
			printf("%d\n",ans);
		}
	}
	
	#ifdef ex1
	for (int i=1;i<=2*Tsize-1;++i)
	{
		printf("%d ",T[i]);
	}
	printf("\n");
	for (int i=1;i<=num;++i)
	{
		printf("%d ",point[i]);
	}
	#endif
}
