#include<bits/stdc++.h>

using namespace std;
const int N=20;
typedef long long LL;

int arr[30];

LL my_pow(LL a,LL i)
{
	if (i==0)
	{
		return 1;
	}
	
	LL temp=my_pow(a,i>>1);
	temp=temp*temp;
	
	if (i&1) temp=(LL)temp*a;
	return temp;
}

void solve(int i,int p,LL &ans)
{
	while (arr[p]==i)
	{
		++p;
	}
	if (p==N+1) return;
	solve(6-arr[p]-i,p+1,ans);
	ans+=my_pow(2,N-p);
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int m;
	scanf("%d",&m);
	
	for (int i=1;i<=N;++i)
	{
		scanf("%d",&arr[i]);
	}
	
	LL ans=0;
	
	solve(arr[1],1,ans);
	//cout<<ans<<endl;
	if (ans>m)
	{
		printf("NO\n");
	}
	else
	{
		printf("YES\n");
	}
}
