#include<bits/stdc++.h>

#define clr(x,y) memset((x),(y),sizeof(x))

using namespace std;
typedef long long LL;

LL C[50][50];

int main(void)
{
	#ifdef ex
	freopen ("../in.txt","r",stdin);
	//freopen ("../out.txt","w",stdout);
	#endif

	LL n,k;
	cin>>n>>k;

	LL kk=k+n-1;
	C[kk][0]=1;
	for (int i=1;i<=kk;++i)
    {
        C[kk][i]=C[kk][i-1]*(kk-i+1)/i;
    }

    cout<<C[kk][n-1]<<endl;
}
