#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
typedef struct S S;

const int maxn=1e6;

struct S
{
	LL a,b,c;
};

S p1[maxn+5];
S p2[2*maxn+5];
LL A[30];
LL B[30];
LL C[30];

int num=0;
int mid;

void dfs(int s,int t,LL a,LL b,LL c,S *p)
{
	if (s==t+1)
	{
		p[++num]=(S){a,b,c};
	}
	else
	{
		dfs(s+1,t,a+A[s],b,c,p);
		dfs(s+1,t,a,b+B[s],c,p);
		dfs(s+1,t,a,b,c+C[s],p);
	}
}

bool cmp(const S &x,const S &y)
{
	if (x.a!=y.a) return x.a<y.a;
	else if (x.b!=y.b) return x.b<y.b;
	else return x.c<y.c;
}


int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n;
	LL AA,BB,CC;
	
	scanf("%d%lld%lld%lld",&n,&AA,&BB,&CC);
	for (int i=1;i<=n;++i)
	{
		scanf("%lld%lld%lld",&A[i],&B[i],&C[i]);
	}
	mid=n/2;
	
	dfs(1,mid,0LL,0LL,0LL,p1);
	sort(p1+1,p1+num+1,cmp);
	
	int num2=num;
	num=0;
	dfs(mid+1,n,0LL,0LL,0LL,p2);
	
	bool f=false;
	for (int i=1;i<=num;++i)
	{
		LL ta=-AA-p2[i].a;
		LL tb=-BB-p2[i].b;
		LL tc=-CC-p2[i].c;
		
		S t=(S){ta,tb,tc};
		int k=lower_bound(p1+1,p1+num2+1,t,cmp)-p1;
		if (p1[k].a==t.a && p1[k].b==t.b && p1[k].c==t.c)
		{
			f=true;
			break;
		}
	}
	
	if (f==true)
	{
		printf("YES\n");
	}
	else
	{
		printf("NO\n");
	}
}
