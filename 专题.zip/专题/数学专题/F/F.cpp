#include<bits/stdc++.h>

#define clr(x,y) memset((x),(y),sizeof(x))

using namespace std;
typedef long long LL;

const int maxn=1e7;

bool vis[maxn+5];
int  ans[maxn+5];
int prime[maxn+5];
int now[maxn+5];
int T[maxn+5];

inline int calc(int a,int b)
{
    if (b==1) return a;
    if (b>=10) return a*100+b;
    else return a*10+b;
}

int main(void)
{
	#ifdef ex
	freopen ("../in.txt","r",stdin);
	//freopen ("../out.txt","w",stdout);
	#endif

	int n;
	scanf("%d",&n);

    int cnt=0;
    LL sum=1;
    for (int i=2;i<=n;++i)
    {
        if (!vis[i])
        {
            prime[++cnt]=i;
            ans[i]=1;
            now[i]=i;
            T[i]=1;
        }

        for (int j=1;j<=cnt && i*prime[j]<=n; ++j)
        {
            vis[i*prime[j]]=true;
            now[i*prime[j]]=prime[j];
            if (i%prime[j]==0)
            {
                ans[i*prime[j]]=ans[i];
                T[i*prime[j]]=T[i]+1;
                break;
            }
            else
            {
                ans[i*prime[j]]=ans[i]*calc(now[i],T[i]);
                T[i*prime[j]]=1;
            }
        }

        sum+=ans[i]*calc(now[i],T[i]);
    }

    printf("%lld\n",sum);
}
