#include<bits/stdc++.h>

using namespace std;
const int maxn=1e5;
const int SIZE=1<<18;

bitset<100> T[SIZE];

int tree_size(int n)
{
	int k=1;
	while (k<n)
	{
		k<<=1;
	}
	return k;
}

void build(int k,int l,int r)
{
	if (r-l>1)
	{
		int mid=(l+r)>>1;
		build(k<<1,l,mid);
		build((k<<1)+1,mid+1,r);
	}
	T[k]=T[k<<1]|T[(k<<1)+1];
}

void update(int k,int cl,int cr,int l,int r,int x)
{
	if (cl>r || cr<l) return;
	else if (l<=cl && cr<=r)
	{
		T[k].reset();
		T[k][x]=1;
		return;
	}
	else
	{
		if (T[k].count()==1)
		{
			T[k<<1]=T[k];
			T[(k<<1)+1]=T[k];
		}
		int mid=(cl+cr)>>1;
		update(k<<1,cl,mid,l,r,x);
		update((k<<1)+1,mid+1,cr,l,r,x);
		T[k]=T[k<<1]|T[(k<<1)+1];
	}
}

bitset<100> query(int k,int cl,int cr,int l,int r)
{
	if (cl>r || cr<l) return 0;
	else if (l<=cl && cr<=r)
	{
		return T[k];
	}
	else
	{
		if (T[k].count()==1)
		{
			return T[k];
		}
		int mid=(cl+cr)>>1;
		return query(k<<1,cl,mid,l,r)|query((k<<1)+1,mid+1,cr,l,r);
	}
}
int main(void)
{
	#ifdef ex
	freopen("in.txt","r",stdin);
	#endif
	
	int n,m,q;
	
	scanf("%d%d",&n,&m);
	
	int Tsize=tree_size(n);
	
	int a;
	for (int i=0;i<=n-1;++i)
	{
		scanf("%d",&a);
		T[Tsize+i][a-1]=1;
	}
	build(1,1,Tsize);
	
	char s[3];
	int l,r,x;
	
	scanf("%d",&q);
	while (q--)
	{
		scanf("%s",s);
		if (s[0]=='M')
		{
			scanf("%d%d%d",&l,&r,&x);
			update(1,1,Tsize,l,r,x-1);
		}
		else
		{
			scanf("%d%d",&l,&r);
			bitset<100> ans=query(1,1,Tsize,l,r);
			printf("%d\n",ans.count());
		}
	}
}


