#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=200;
const int inf=1e9;

pair <int,int> p[maxn+5];
int f[maxn+5];
int sum[maxn+5];
int dp[maxn+5];

void solve()
{
	fill (f+1,f+1+maxn,inf);
	p[1]=make_pair(2,3);
	
	for (int i=2;i<=maxn;++i)
	{
		for (int j=i+1;j<=maxn;++j)
		{
			memset(dp,0,sizeof(dp));
			memset(sum,0,sizeof(sum));
			dp[0]=0;
			dp[1]=1;
			sum[1]=1;
			for (int k=2;k<=maxn;++k)
			{
				if (k>=j)
				{
					dp[k]=min(dp[k-1],min(dp[k-i],dp[k-j]))+1;
				}
				else if (k>=i)
				{
					dp[k]=min(dp[k-1],dp[k-i])+1;
				}
				else
				{
					dp[k]=dp[k-1]+1;
				}
				sum[k]=sum[k-1]+dp[k];
				if (sum[k]<f[k])
				{
					f[k]=sum[k];
					p[k]=make_pair(i,j);
				}
			}
		}
	}
}
int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	solve();
	int T,n;
	
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		printf("%d %d %d\n",1,p[n].first,p[n].second);
	}
	
}
