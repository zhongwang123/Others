#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
const int maxn=1e5;
const LL inf=-1;
int arr[maxn+5];
LL T[4*maxn+5];

int Tsize;

int tree_size(int n)
{
	int k=1;
	while (k<n)
	{
		k<<=1;
	}
	return k;
}

void update(int x,int p)
{
	x=x+Tsize-1;
	T[x]+=p;
	x>>=1;
	while (x>=1)
	{
		T[x]=max(T[x<<1],T[(x<<1)+1]);
		x>>=1;
	}
}

LL query(int k,int cl,int cr,int l,int r)
{
	if (l<=cl && cr<=r)
	{
		return T[k];
	}
	else if (cl>r || cr<l)
	{
		return inf;
	}
	else
	{
		int mid=(cl+cr)>>1;
		LL temp=max(query(k<<1,cl,mid,l,r),query((k<<1)+1,mid+1,cr,l,r));
		return temp;
	}
}
int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int N,Q;
	scanf("%d%d",&N,&Q);
	
	Tsize=tree_size(N);

	int op,x,p,l,r;
	while (Q--)
	{
		scanf("%d",&op);
		if (op==1)
		{
			scanf("%d%d",&x,&p);
			update(x,p);
		}
		else
		{
			scanf("%d%d",&l,&r);
			LL ans=query(1,1,Tsize,l,r);
			printf("%lld\n",ans);
		}
	}
}
