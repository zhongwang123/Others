#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<algorithm>

using namespace std;

#define local1 0

const int maxn=1000000;

long long a[maxn+2];
int d[100];
char s[maxn+2];

inline long long pw(int n);

int main(void)
{
	#ifdef local
	freopen("in.txt","r",stdin);
	#endif
	
	int t;
	int i,j,k,length,count,tot;
	int sym,p;
	long long temp;
	long long ans;
	char cc;
	scanf("%d",&t);
	
	for (i=1;i<=t;++i)
	{
		scanf("%s",s);
		length=strlen(s);
		count=1;
		tot=1;a[tot]=0;
		for (j=0;j<=length-1;++j)
		{
			cc=s[j];
			if (isdigit(cc)) 
			{
				d[count]=cc-'0';
				++count;
			}
			if (j==length-1 || !isdigit(s[j+1]))
			{
				a[tot]=0;
				for (k=1;k<=count-1;++k)
				{
					a[tot]+=d[k]*pw(count-1-k);
				}
				if (a[tot-1]==-1 || a[tot-1]==-2)
				{
					if (a[tot-1]==-1) temp=a[tot-2]/a[tot];
					if (a[tot-1]==-2) temp=a[tot-2]*a[tot];
					a[tot-2]=temp;
					tot-=2;
				}
				++tot;
				count=1;
			}
			
			if (!isdigit(cc)) 
			{
				if (cc=='/') a[tot]=-1;
				if (cc=='*') a[tot]=-2;
				if (cc=='+') a[tot]=-3;
				if (cc=='-') a[tot]=-4;
				++tot;
			}
		}
		a[tot]=-5;
		
		ans=a[1];
		sym=2;
		p=3;
		
		#ifdef exam
		for (i=1;i<=tot;++i) printf("%lld ",a[i]);
		#endif
		while (a[sym]!=-5)
		{
			if (a[sym]==-3) ans+=a[p];
			else if (a[sym]==-4) ans-=a[p];
			p+=2;
			sym+=2;
			#ifdef exam
			printf("%lld ",ans);
			#endif
		}
		
		printf("%lld\n",ans);
	}
	
}

inline long long pw(int n)
{
	long long sum=1;
	for (int i=1;i<=n;++i) sum=sum*10;
	return sum;
}


