#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
typedef struct Pair Pair;

const int maxn=1e3;

int dp[maxn+5][maxn+5];//ȡi,j�� 
int mx[maxn+5][maxn+5];//ȡ��i,jʱ�����Ž� 
int mat[maxn+5][maxn+5];

struct Pair
{
	int A;
	int B;
};

Pair p[maxn+5];

bool cmp(const Pair &a,const Pair &b)
{
	return a.B>b.B;
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,m;
	scanf("%d%d",&n,&m);
	
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&p[i].A);
	}
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&p[i].B);
	}
	
	sort(p+1,p+n+1,cmp);
	
	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=m;++j)
		{
			mat[i][j]=max(0,p[i].A-(j-1)*p[i].B);
		}
	}
	
	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=m;++j)
		{
			dp[i][j]=mx[i-1][j-1]+mat[i][j];
			mx[i][j]=max(dp[i][j],mx[i-1][j]);
		}
	}
	
	int ans=0;
	for (int i=1;i<=m;++i)
	{
		ans=max(ans,mx[n][i]);
	}
	
	printf("%d\n",ans);
}
