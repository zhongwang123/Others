

#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
typedef struct S S;
const int maxn=4e6;
const long double inf=(1e18+10000);
const long double eps=1e-8;

pair <LL,LL> cood[2005];

struct S
{
	LL x;
	LL y;
	long double b;
};

S line[maxn+5];

bool cmp(const S &a,const S &b)
{
	if (a.x!=b.x) return a.x<b.x;
	else if (a.y!=b.y) return a.y<b.y;
	else
	{
		return a.b<b.b;
	}
}

int main(void)
{
	#ifdef ex
	freopen("in.txt","r",stdin);
	#endif
	
	int n;
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
	{
		scanf("%lld%lld",&cood[i].first,&cood[i].second);
	}
	
	sort(cood+1,cood+n+1);
	
	int num=0;
	for (int i=1;i<=n;++i)
	{
		cood[++num]=cood[i];
		while (cood[i]==cood[i+1])
		{
			++i;
		}
	}
	//cout<<num<<endl;
	long double b=0.0;
	int nx=0;
	for (int i=1;i<=num;++i)
	{
		for (int j=i+1;j<=num;++j)
		{
			LL x=cood[j].first-cood[i].first;
			LL y=cood[j].second-cood[i].second;
			if (x==0) b=cood[j].first;
			else if (y==0)
			{
				b=cood[j].second;
			}
			else
			{
				b=-(cood[i].first*cood[j].second-cood[j].first*cood[i].second)*1.0/(1.0*x);
				//b=-(1.0*y)/(1.0*x)*(1.0*cood[i].first)+(1.0)*cood[i].second;
			}
			line[++nx]=(S){x,y,b};
		}
	}
	
	sort(line+1,line+1+nx,cmp);
	
	int s=1;
	LL ans=0;
	line[nx+1].x=-1;line[nx+1].y=-1;
	
	for (int i=1;i<=nx;++i)
	{
		if (line[i].x==line[i+1].x && line[i].y==line[i+1].y) continue;
		LL sum=(i-s+1);
		ans+=(sum-1)*sum/2;
		
		LL sa=0;
		long double tb=line[s].b;
		while (s<=i+1)
		{
			if (fabs(line[s].b-tb)<eps) ++sa;
			else
			{
				ans-=(sa-1)*sa/2;
				sa=1;
				tb=line[s].b;
			}
			++s;
		} 
		//cout<<ans<<endl;
		--s;
	}
	#ifdef ex1
	for (int i=1;i<=nx;++i)
	{
		printf("%lld %lld %Lf\n",line[i].x,line[i].y,line[i].b);
		//printf("%lld %lld\n",line[i].x,line[i].y);
	}
	#endif
	
	ans/=2;
	printf("%lld\n",ans);
	
}


