#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
typedef struct S S;
const int maxn=2e5;

struct S
{
	LL y1,y2;
};

LL point[maxn+5];
LL temp[maxn+5];
int bit[maxn+5];
S line[maxn+5];

int n;

bool cmp(const S &a,const S &b)
{
	if (a.y1!=b.y1) return a.y1>b.y1;
	else
	{
		return a.y2<b.y2;
	}
}

int sum(int i)
{
	int s=0;
	while (i>0)
	{
		s+=bit[i];
		i-=i&(-i);
	}
	return s;
}

void add(int i,int x)
{
	while (i<=n)
	{
		bit[i]+=x;
		i+=i&(-i);
	}
}

int main(void)
{
	#ifdef ex1
	freopen ("in.txt","r",stdin);
	#endif
	
	LL u,v;
	LL k,b;
	
	scanf("%d",&n);
	scanf("%lld%lld",&u,&v);
	
	for (int i=1;i<=n;++i)
	{
		scanf("%lld%lld",&k,&b);
		line[i].y1=k*u+b;
		line[i].y2=k*v+b;
		temp[i]=line[i].y2;
	}
	
	sort(temp+1,temp+n+1);
	
	int num=0;
	temp[n+1]=-temp[n];
	
	for (int i=1;i<=n;++i)
	{
		point[++num]=temp[i];
		while (temp[i]==temp[i+1])
		{
			++i;
		}
	}
	
	sort(line+1,line+n+1,cmp);
	
	LL ans=0;
	for (int i=1;i<=n;++i)
	{
		LL t=line[i].y2;
		int x=lower_bound(point+1,point+num+1,t)-point;
		ans+=sum(x);
		add(x,1);
	}
	
	#ifdef ex1
	for (int i=1;i<=7;++i)
	{
		printf("%d ",point[i]);
	}
	#endif
	
	printf("%lld\n",ans);
}
