#include<bits/stdc++.h>

#define clr(x,y) memset((x),(y),sizeof(x))

using namespace std;
typedef long long LL;

int main(void)
{
	#ifdef ex
	freopen ("../in.txt","r",stdin);
	//freopen ("../out.txt","w",stdout);
	#endif

	int n;
	scanf("%d",&n);

	double d=sqrt(2)/2;
	double ans=(d+sqrt(0.5+0.5*n))/n;
	for (int i=1;i<=n;++i)
    {
        for (int j=1;j<=n;++j)
        {
            if (i==j)
            {
                printf("%.12f ",d);
                continue;
            }
            printf("0 ");
        }
        printf("\n");
    }

    for (int i=1;i<=n;++i)
    {
        printf("%.12f ",ans);
    }
}
