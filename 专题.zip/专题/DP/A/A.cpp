#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

int dp[10005];
int T[5005];
int V[5005];

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,m;
	scanf("%d%d",&n,&m);
	
	for (int i=1;i<=m;++i)
	{
		scanf("%d%d",&T[i],&V[i]);
	}
	memset(dp,0,sizeof(dp));
	
	for (int i=1;i<=m;++i)
	{
		for (int j=n;j>=0;--j)
		{
			if (j>=T[i])
			{
				dp[j]=max(dp[j],dp[j-T[i]]+V[i]);
			}
			else
			{
				dp[j]=dp[j];
			}
		}
	}
	
	printf("%d\n",dp[n]);
}
