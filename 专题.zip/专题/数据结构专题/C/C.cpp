

#include<bits/stdc++.h>

using namespace std;
const int maxn=1e5;

int arr[maxn+5];
int Next[maxn+5];
int pre[maxn+5];
int eva[maxn+5];
int vis[maxn+5];
int f[maxn+5];

int n;

bool check(int s,int o)
{
	int t=Next[s];
	if (vis[t])
	{
		if (vis[t]!=o) return true;
		else if (eva[s]*f[s]==f[t])
		return true;
		else
		return false;
	}
	else
	{
		vis[t]=o;
		f[t]=eva[s]*f[s];
		return check(t,o);
	}
}
int main(void)
{
	#ifdef ex
	freopen("in.txt","r",stdin);
	#endif
	
	scanf("%d",&n);
	
	int a,t;
	for (int i=1;i<=n;++i)
	{
		scanf("%d%d",&a,&t);
		Next[i]=a;
		pre[a]=i;
		if (t==1) eva[i]=1;
		else eva[i]=-1;
	}
	memset(vis,0,sizeof(vis));
	memset(f,0,sizeof(f));
	for (int i=1;i<=n;++i)
	{
		if (!vis[i])
		{
			vis[i]=i;
			f[i]=1;
			if (!check(i,i))
			{
				printf("One face meng bi\n");
				return 0;
			}
		}
	}
	/*
	printf("One face meng bi\n");
	printf("Time to show my power");
	*/
	
	printf("Time to show my power\n");
}


