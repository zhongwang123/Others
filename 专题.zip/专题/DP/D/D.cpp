#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=300;
const int h=1e9+7;

LL dp[maxn+5][maxn+5];
bool vis[maxn+5][maxn+5];
char s[maxn+5];

bool match(int i,int j)
{
	return ((s[i]=='(' && s[j]==')') || (s[i]=='[' && s[j]==']'));
}

LL dfs(int i,int j)
{
	if (vis[i][j]) return dp[i][j];
	
	vis[i][j]=true;
	if (j<=i) return dp[i][j]=0;
	if (j==i+1)
	{
		if (match(i,j)) return dp[i][j]=1;
		else return dp[i][j]=0;
	}
	else
	{
		dp[i][j]=(dp[i][j]+dfs(i+1,j))%h;
		for (int k=i+1;k<=j;++k)
		{
			if (match(i,k))
			{
				dp[i][j]=(dp[i][j]+(dfs(i+1,k-1)+1)*(dfs(k+1,j)+1))%h;
			}
		}
		
		return dp[i][j];
	}
}
int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n;
	scanf("%d",&n);
	scanf("%s",s+1);
	
	memset(dp,0,sizeof(dp));
	memset(vis,0,sizeof(vis));
	
	LL ans=dfs(1,n);
	printf("%lld\n",ans);
}
