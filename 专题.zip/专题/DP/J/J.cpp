#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=1e6;
const int inf=1e9+9;

deque <int> deq;
deque <int> id;
int A[2*maxn+5];
int sum[2*maxn+5];
int dp[2*maxn+5];

void deq_insert(int x,int i)
{
	while (!deq.empty() && deq.back()>x)
	{
		deq.pop_back();
		id.pop_back();
	}
	deq.push_back(x);
	id.push_back(i);
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int N,K;
	scanf("%d%d",&N,&K);
	
	for (int i=1;i<=N;++i)
	{
		scanf("%d",&A[i]);
		sum[i]=sum[i-1]+A[i];
	}
	
	for (int i=N+1;i<=2*N-1;++i)
	{
		A[i]=A[i-N];
		sum[i]=sum[i-1]+A[i];
	}
	
	int ans=-inf;
	int ans_id=0;
	int ans_l=0;
	
	dp[0]=-inf;
	deq.push_back(sum[0]);
	id.push_back(0);
	
	for (int i=1;i<=2*N-1;++i)
	{
		dp[i]=max(dp[i-1],sum[i]-deq.front());
		
		if (dp[i]>ans || (dp[i]==sum[i]-deq.front() && dp[i]==ans && id.front()+1<ans_l))
		{
			ans=dp[i];
			ans_id=i;
			ans_l=id.front()+1;
		}
		
		if (id.front()<=i-K) 
		{
			deq.pop_front();
			id.pop_front();
		}
		deq_insert(sum[i],i);
	}
	if (ans_id>N) ans_id-=N;
	
	printf("%d %d %d\n",ans,ans_l,ans_id);
}
