#include<bits/stdc++.h>

#define clr(x,y) memset((x),(y),sizeof(x))

using namespace std;
typedef long long LL;

const int maxn=1e5;
const int maxv=20;

struct Edge
{
    int to,cost;
};

vector<Edge> G[maxn+5];
int par[maxn+5][maxv];
int depth[maxn+5];
int dist[maxn+5];

int root;

void dfs(int v,int p,int d,int tmp)
{
    par[v][0]=p;
    depth[v]=d;
    dist[v]=dist[p]+tmp;
    for (int i=0;i<G[v].size();++i)
    {
        Edge &e=G[v][i];
        if (e.to!=p) dfs(e.to,v,d+1,e.cost);
    }
}

void init(int n)
{
    clr(par,-1);
    dfs(root,-1,0,0);

    for (int k=0;k+1<maxv;++k)
    {
        for (int v=1;v<=n;++v)
        {
            if (par[v][k]<0) par[v][k+1]=-1;
            else par[v][k+1]=par[par[v][k]][k];
        }
    }
}

int lca(int u,int v)
{
    if (depth[u]>depth[v]) swap(u,v);
    for (int k=0;k<maxv;++k)
    {
        if ((depth[v]-depth[u])>>k & 1)
            v=par[v][k];
    }

    if (u==v) return u;
    for (int k=maxv-1;k>=0;--k)
    {
        if (par[u][k]!=par[v][k])
        {
            u=par[u][k];
            v=par[v][k];
        }
    }
    return par[u][0];
}

int main(void)
{
	#ifdef ex
	freopen ("../in.txt","r",stdin);
	//freopen ("../out.txt","w",stdout);
	#endif

	int n,m;
	scanf("%d%d",&n,&m);

	int a,b,c;
	for (int i=1;i<=n-1;++i)
    {
        scanf("%d%d%d",&a,&b,&c);
        G[a].push_back((Edge){b,c});
        G[b].push_back((Edge){a,c});
    }

    root=1;
    init(n);

    int u,v;
    for (int i=1;i<=m;++i)
    {
        scanf("%d%d",&u,&v);
        int p=lca(u,v);
        int ans=dist[u]-dist[p]+dist[v]-dist[p];
        printf("%d\n",ans);
    }
}
