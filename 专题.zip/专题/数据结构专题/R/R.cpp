#include<bits/stdc++.h>

using namespace std;
const int maxn=1e4;
typedef struct S S;

struct S
{
	int y1,y2;
};

S p[100*maxn+5];
int bit[maxn+5];

bool cmp(const S &a,const S &b)
{
	if (a.y1!=b.y1) return a.y1<b.y1;
	else
	{
		return a.y2<b.y2;
	}
}

int sum(int i)
{
	int s=0;
	while (i>0)
	{
		s+=bit[i];
		i-=i&(-i);
	}
	return s;
}

void add(int i,int x,int n)
{
	while (i<=n)
	{
		bit[i]+=x;
		i+=i&(-i);
	}
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int T;
	int n,m,k;
	
	scanf("%d",&T);
	for (int j=1;j<=T;++j)
	{
		scanf("%d%d%d",&n,&m,&k);
		for (int i=1;i<=k;++i)
		{
			scanf("%d%d",&p[i].y1,&p[i].y2);
		}
		sort(p+1,p+k+1,cmp);
		
		int ans=0;
		for (int i=1;i<=k;++i)
		{
			int x=p[i].y2;
			ans+=(i-1-sum(x));
			add(x,1,m);
		}
		
		printf("Test case %d: %d\n",j,ans);
		memset(bit,0,sizeof(bit));
	}
}
