#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
const int maxn=1e6;
const int inf=1e9+1000;

int A[maxn+5];
int B[maxn+5];
int p[maxn+5];
int dp[maxn+5];

map<int,int> mapx;

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,m;
	scanf("%d%d",&n,&m);
	
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&A[i]);
		mapx[A[i]]=i;
	}
	
	int num=0;
	for (int i=1;i<=m;++i)
	{
		scanf("%d",&B[i]);
		if (mapx.count(B[i]))
		{
			p[++num]=mapx[B[i]];
		}
	}
	
	fill(dp+1,dp+1+num,inf);
	for (int i=1;i<=num;++i)
	{
		*lower_bound(dp+1,dp+1+num,p[i])=p[i];
	}
	
	int ans=lower_bound(dp+1,dp+1+num,inf)-dp;
	
	printf("%d\n",ans);
	
	#ifdef ex1
	for (int i=1;i<=num;++i)
	{
		printf("%d ",p[i]);
	}
	#endif
	
}
