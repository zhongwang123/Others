#include<bits/stdc++.h>

#define clr(x,y) memset((x),(y),sizeof(x))

using namespace std;
typedef long long LL;

inline int readint(void)
{
	char c=getchar();
	while (!isdigit(c)) c=getchar();

	int x=0;
	while (isdigit(c))
	{
		x=x*10+c-'0';
		c=getchar();
	}
	return x;
}

int buf[11];
inline void writeint(int i)
{
    //clr(buf,0);
    int p=0;
    if (i==0)
    {
        putchar('0');
        putchar('\n');
        return;
    }
    else while(i)
    {
        buf[p++]=i%10;
        i/=10;
    }
    for (int j=p-1;j>=0;--j) putchar('0'+buf[j]);
    putchar('\n');
}

LL euler_phi(LL n)//nµÄÅ·À­º¯ÊýÖµ
{
    if (n==1) return 1;

    //LL m=(LL)sqrt(n+0.5);
    LL ans=n;
    for (LL i=2;i*i<=n;++i)
    {
        if (n%i==0)
        {
            ans=ans/i*(i-1);
            while (n%i==0) n/=i;
        }
    }
    if (n>1) ans=ans/n*(n-1);
    return ans;
}

LL pow_mod(LL a,LL b,LL m)
{
    LL ans=1%m;
    a%=m;
    while (b)
    {
        if (b&1) ans=(ans*a)%m;
        a=(a*a)%m;
        b>>=1;
    }
    return ans;
}

LL solve(LL p,LL x)
{
    if (p==1) return 0L;

    LL k=1;
    LL q=p;
    int cnt=0;
    while (!(p&1))
    {
        p>>=1;
        k<<=1;
        ++cnt;
    }

    LL eu=euler_phi(p);
    LL tmp=solve(eu,cnt);
    LL ans=k*pow_mod(2,tmp,p)-x%q;
    //while (ans<0) ans+=q;
    if (ans<0)
    {
        ans%=q;
        ans+=q;
    }
    return ans;
}
int main(void)
{
	#ifdef ex
	freopen ("../in.txt","r",stdin);
	//freopen ("../out.txt","w",stdout);
	#endif

	int T;
	LL p;

	//scanf("%d",&T);
	T=readint();
	while (T--)
    {
        //scanf("%lld",&p);
        p=readint();
        LL ans=solve(p,0);
        //printf("%lld\n",ans);
        writeint(ans);
    }
}

