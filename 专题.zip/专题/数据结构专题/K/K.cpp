#include<bits/stdc++.h>

using namespace std;
const int maxn=1e5;

int n;

struct S
{
	int l;
	int r;
	int id;
};

int bit[maxn+5];
int p[10005];
int arr[maxn+5];
int ans[maxn+5];
struct S seg[maxn+5];

int sum(int i)
{
	int s=0;
	while (i>0)
	{
		s+=bit[i];
		i-=i&(-i);
	}
	return s;
}

void add(int i,int x)
{
	while (i<=n)
	{
		bit[i]+=x;
		i+=i&(-i);
	}
}


bool cmp(const struct S &x,const struct S &y)
{
	if (x.r!=y.r) return x.r<y.r;
	else
	{
		return (x.r-x.l)>(y.r-y.l);
	}
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int q;
	scanf("%d%d",&n,&q);
	
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&arr[i]);
	}
	
	for (int i=1;i<=q;++i)
	{
		scanf("%d%d",&seg[i].l,&seg[i].r);
		seg[i].id=i;
	}
	
	sort(seg+1,seg+1+q,cmp);
	
	int s=1;
	for (int i=1;i<=q;++i)
	{
		for (int j=s;j<=seg[i].r;++j)
		{
			if (p[arr[j]])
			{
				add(p[arr[j]],-1);
			}
			add(j,1);
			p[arr[j]]=j;
		}
		s=seg[i].r+1;
		ans[seg[i].id]=sum(seg[i].r)-sum(seg[i].l-1);
	}
	
	for (int i=1;i<=q;++i)
	{
		printf("%d\n",ans[i]);
	}
}
