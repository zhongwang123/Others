#include<bits/stdc++.h>

using namespace std;
typedef struct S S;
const int maxn=1e5+1000;

struct S
{
	int t;
	int v;
};

vector <int> vi[5005];
S r[maxn+5];

struct cmp_v
{
	bool operator() (const int &a,const int &b)
	{
		return r[a].v>r[b].v;
	}
};

int p[5005];
priority_queue <int,vector<int>,cmp_v> q;


inline int readint(void)
{
	char c=getchar();
	while (!isdigit(c)) c=getchar();
	
	int x=0;
	while (isdigit(c))
	{
		x=x*10+c-'0';
		c=getchar();
	}
	return x;
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n;
	
	int a,v;
	int tmax=0;
	
	memset(p,0,sizeof(p));
	
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
	{
		//a=readint();
		scanf("%d",&a);
		r[i].t=a;
		++p[a];
		vi[a].push_back(i);
		tmax=max(tmax,a);
	}
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&r[i].v);
		//r[i].v=readint();
	}
	
	
	int ans=0;
	int num1=0;
	
	for (int i=1;i<=tmax;++i)
	{
		if (p[i])
		{
			num1+=p[i];
			for (int j=0;j<=p[i]-1;++j)
			{
				q.push(vi[i][j]);
			}
			if (num1>i)
			{
				for (int j=1;j<=num1-i;++j)
				{
					q.pop();
				}
				num1=i;
			}
		}
	}
	
	
	while (!q.empty())
	{
		ans+=r[q.top()].v;
		q.pop();
	}
	
	printf("%d\n",ans);
}
