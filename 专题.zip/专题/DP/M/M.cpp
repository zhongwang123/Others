#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=500;

int mat[maxn+5][maxn+5];
int xsum[maxn+5][maxn+5]; //i��ǰj���� 
int sum[maxn+5][maxn+5]; //i��ǰj���� 
int dp[maxn+5][maxn+5];

int f(int x,int y)
{
	int res=0;
	for (int i=0;i<=2;++i)
	{
		for (int j=0;j<=2;++j)
		{
			res+=mat[x+i][y+j];
		}
	}
	res-=mat[x+1][y];
	res-=mat[x+1][y+1];
	return res;
}

class SUM
{
	public:
		int n;
		int m;
		LL sum[maxn+5][maxn+5];
		LL X_sum[maxn+5][maxn+5];
		
		SUM()
		{
			memset(sum,0,sizeof(sum));
			memset(X_sum,0,sizeof(X_sum));
		}
		
		void init(int mat[][maxn+5],int n,int m)
		{
			this->n=n;
			this->m=m;
			for (int i=1;i<=n;++i)
			{
				for (int j=1;j<=m;++j)
				{
					X_sum[i][j]=X_sum[i][j-1]+mat[i][j];
				}
			}
			for (int i=1;i<=n;++i)
			{
				for (int j=1;j<=m;++j)
				{
					sum[i][j]=sum[i-1][j]+X_sum[i][j];
				}
			}
		}
		
		LL query(int x1,int y1,int x2,int y2)
		{
			return sum[x2][y2]-sum[x2][y1-1]-sum[x1-1][y2]+sum[x1-1][y1-1];
		}
};

SUM Sum;

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,m;
	scanf("%d%d",&n,&m);
	
	int ans=-1e9;
	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=m;++j)
		{
			scanf("%d",&mat[i][j]);
		}
		//printf("\n");
	}
	
	Sum.init(mat,n,m);
	
	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=m;++j)
		{
			if (i+2<=n && j+2<=m)
			{
				dp[i][j]=f(i,j);
				ans=max(ans,dp[i][j]);
			}
		}
		//printf("\n");
	}
	
	for (int k=5;k<=min(m,n);k+=2)
	{
		for (int i=1;i<=n;++i)
		{
			for (int j=1;j<=m;++j)
			{
				int x2=i+k-1;
				int y2=j+k-1;
				
				if (x2>n || y2>m)
				{
					continue;
				}
				else
				{
					dp[i][j]=Sum.query(i,j,x2,y2)-dp[i+1][j+1]-mat[i+1][j];
					ans=max(ans,dp[i][j]);
				}
			}
			//printf("\n");
		}
	}
	
	printf("%d",ans);
}
