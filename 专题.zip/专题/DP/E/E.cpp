#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=300;
const double eps=1e-8;

double A[maxn+5][maxn+5];
double ans[maxn+5];
bool Free[maxn+5];
int To[maxn+5];

int Gauss(int n)
{
	int res=0;
	int r=1;
	for (int i=1;i<=n;++i)
	{
		Free[i]=true;
	}
	for (int i=1;i<=n;++i)
	{
		for (int j=r;j<=n;++j)
		{
			if (fabs(A[j][i]>eps))
			{
				for (int k=i;k<=n+1;++k)
				{
					swap(A[j][k],A[r][k]);
				}
				break;
			}
		}
		
		if (fabs(A[r][i])<eps)
		{
			++res;
			continue;
		}
		
		for (int j=1;j<=n;++j)
		{
			if (j!=r && fabs(A[j][i])>eps)
			{
				double temp=A[j][i]/A[r][i];
				for (int k=i;k<=n+1;++k)
				{
					A[j][k]-=temp*A[r][k];
				}
			}
			
		}
		Free[i]=false;
		++r;
	}
	
	for (int i=1;i<=n;++i)
	{
		if (!Free[i])
		{
			for (int j=1;j<=n;++j)
			{
				if (fabs(A[j][i])>0)
				{
					ans[i]=A[j][n+1]/A[j][i];
				}
			}
		}
	}
	
	return res;
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,m;
	scanf("%d%d",&n,&m);
	
	int p,q;
	for (int i=1;i<=m;++i)
	{
		scanf("%d%d",&p,&q);
		To[p]=q;
	}
	
	
	for (int i=1;i<=n-1;++i)
	{
		if (To[i]!=0)
		{
			A[i][i]=1;
			A[i][To[i]]=-1; 
			A[i][n+1]=0;
			continue;
		}
		int k=6;
		for (int j=1;j<=6;++j)
		{
			int s=i+j;
			if (s>n)
			{
				--k;
				continue;
			}
			else if (To[s]!=0)
			{
				s=To[s];
			}
			
			--A[i][s];
		}
		A[i][i]+=k;
		A[i][n+1]+=6;
	}
	A[n][n]=1;
	A[n][n+1]=0;
	
	
	if (Gauss(n)>0)
	{
		//printf("%d\n",Gauss(n-1));
		printf("-1\n");
	}
	else
	{
		printf("%.12f\n",ans[1]);
	}
}
