#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=1000;
const LL inf=1e17;

LL mat[maxn+5][maxn+5];
LL sum[maxn+5][maxn+5]; 
LL dpL[maxn+5][maxn+5];
LL dpR[maxn+5][maxn+5];
LL dp[maxn+5][maxn+5];

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,m;
	scanf("%d%d",&n,&m);
	
	LL ans=-inf;
	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=m;++j)
		{
			scanf("%lld",&mat[i][j]);
			sum[i][j]=sum[i][j-1]+mat[i][j];
			ans=max(ans,mat[i][j]);
		}
	}
	
	for (int i=1;i<=n;++i)
	{
		dpL[i][1]=mat[i][1];
		for (int j=2;j<=m;++j)
		{
			dpL[i][j]=max(dpL[i][j-1],0LL)+mat[i][j];
		}
		dpR[i][m]=mat[i][m];
		for (int j=m-1;j>=1;--j)
		{
			dpR[i][j]=max(dpR[i][j+1],0LL)+mat[i][j];
		}
	}
	
	for (int i=1;i<=n;++i)
	{
		LL maxv=-inf;
		for (int j=1;j<=m;++j)
		{
			if (dp[i-1][j]>0) maxv=max(maxv,dp[i-1][j]-sum[i][j]+dpL[i][j]);
			else maxv=max(maxv,-sum[i][j]+dpL[i][j]);
			dp[i][j]=maxv+dpR[i][j]+sum[i][j-1];
		}
		maxv=-inf;
		for (int j=m;j>=1;--j)
		{
			if (dp[i-1][j]>0) maxv=max(maxv,dp[i-1][j]+dpR[i][j]+sum[i][j-1]);
			else maxv=max(maxv,dpR[i][j]+sum[i][j-1]);
			dp[i][j]=max(dp[i][j],maxv+dpL[i][j]-sum[i][j]);
			ans=max(ans,dp[i][j]);
		}
	}
	
	printf("%lld\n",ans);
}
