#include<bits/stdc++.h>

using namespace std;
const int maxn=1e5;

int A[maxn+5];
int B[maxn+5];
int arr[10*maxn+5];

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	int n;
	scanf("%d",&n);
	
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&A[i]);
	}
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&B[i]);
	}
	
	sort(A+1,A+n+1);
	sort(B+1,B+n+1);
	
	int num=0;
	for (int i=1;i<=n;++i)
	{
		for (int j=1;j<=n;++j)
		{
			if (i*j-1>=n)
			{
				break;
			}
			else
			{
				arr[++num]=A[i]+B[j];
			}
		}
	}
	sort(arr+1,arr+num+1);
	for (int i=1;i<=n;++i)
	{
		printf("%d\n",arr[i]);
	}
}
