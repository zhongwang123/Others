#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
const int maxn=5e5;
const int inf=1e9;

int arr[maxn+5];
int dp[2][maxn+5];
int maxl[maxn+5];
int maxr[maxn+5];
int n;

void solve1(void)
{
	for (int i=1;i<=n;++i)
	{
		dp[0][i]=max(dp[0][i-1],0)+arr[i];
		if (i>=2) maxl[i]=max(maxl[i-1],dp[0][i]);
		else maxl[i]=arr[i];
	}
}

void solve2(void)
{
	for (int i=n;i>=1;--i)
	{
		dp[1][i]=max(dp[1][i+1],0)+arr[i];
		if (i<=n-1) maxr[i]=max(maxr[i+1],dp[1][i]);
		else maxr[i]=arr[i];
	}
}
int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	memset(dp,0,sizeof(dp));
	memset(maxr,0,sizeof(maxr));
	memset(maxl,0,sizeof(maxl));
	
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&arr[i]);
	}
	
	solve1();
	solve2();
	
	int ans=-inf;
	for (int i=2;i<=n-1;++i)
	{
		ans=max(ans,maxl[i-1]+maxr[i+1]);
	}
	printf("%d\n",ans);
}
