#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=5e5;

int A[maxn+5]; 
LL dp[maxn+5];
LL sum[maxn+5];

class Deque
{
	public:
		int head,tail;
		int que[maxn+5];
		
		Deque()
		{
			memset(que,0,sizeof(que));
			head=1;
			tail=1;
		}
		
		bool empty(void)
		{
			return head==tail;
		}
		int size(void)
		{
			return tail-head;
		}
		
		inline int front(void)
		{
			return que[head];
		}
		inline int front(int i)
		{
			return que[head+i];
		}
		inline int back(void)
		{
			return que[tail-1];
		}
		inline int back(int i)
		{
			return que[tail-1-i];
		}
		
		void pop_front(void)
		{
			++head;
		}
		void pop_back(void)
		{
			--tail;
		}
		void push_front(int i)
		{
			que[--head]=i;
		}
		void push_back(int i)
		{
			que[tail++]=i;
		}
};

Deque que;

inline LL getY(int i,int j)
{
	return dp[i]-dp[j]+sum[i]*sum[i]-sum[j]*sum[j];
}

inline LL getX(int i,int j)
{
	return 2*(sum[i]-sum[j]);
}

void update_front(int i)
{
	while (que.size()>=2 && getY(que.front(),que.front(1))>=getX(que.front(),que.front(1))*sum[i])
	{
		que.pop_front();
	}
}

void update_back(int i)
{
	while (que.size()>=2 && getY(que.back(),que.back(1))*getX(i,que.back())>=getX(que.back(),que.back(1))*getY(i,que.back()))
	{
		que.pop_back();
	}
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n,m;
	scanf("%d%d",&n,&m);
	
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&A[i]);
		sum[i]=sum[i-1]+A[i];
	}
	
	dp[0]=0;
	que.push_back(0);
	
	for (int i=1;i<=n;++i)
	{
		update_front(i);
		dp[i]=dp[que.front()]+(sum[i]-sum[que.front()])*(sum[i]-sum[que.front()])+m;
		
		update_back(i);
		que.push_back(i);
	}
	
	printf("%lld\n",dp[n]);
}
