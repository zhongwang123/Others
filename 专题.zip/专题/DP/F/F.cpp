#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=4e4;
const LL inf=1e15;

LL dp[maxn+5];
bool vis[maxn+5];
int D[20];

void init()
{
	int k=(1<<15)-1;
	for (int i=0;i<=k;++i)
	{
		LL temp=0;
		for (int j=0;j<=14;++j)
		{
			if (i>>j&1)
			{
				temp+=D[j];
			}
		}
		dp[i]=temp;
	}
}

LL dfs(int id)
{
	if (vis[id]) return dp[id];
	vis[id]=true;
	
	for (int j=(id-1)&id;j>0;j=(j-1)&id)
	{
		dp[id]=min(dfs(j)+dfs(j^id),dp[id]);
	}
	return dp[id];
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	memset(vis,0,sizeof(vis));
	
	for (int i=0;i<=14;++i)
	{
		scanf("%d",&D[i]);
	}
	
	init();
	
	int n;
	scanf("%d",&n);
	for (int i=1;i<=n;++i)
	{
		int t,tt;
		LL cost;
		int k=0;
		scanf("%d",&t);
		for (int j=1;j<=t;++j)
		{
			scanf("%d",&tt);
			k=k|(1<<(tt-1));
		}
		scanf("%lld",&cost);
		dp[k]=min(dp[k],cost);
	}
	LL ans=dfs((1<<15)-1);
	printf("%lld\n",ans);
	
}
