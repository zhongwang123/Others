#include<bits/stdc++.h>

using namespace std;
const int maxn=1e6;

set<int,greater<int> >s1;
set<int,less<int> >s2;
queue<int> q;

inline void adjust(void)
{
	if (s1.size()>s2.size()+1)
	{
		int t=*s1.begin();
		s2.insert(t);
		s1.erase(s1.begin());
	}
	if (s2.size()>s1.size()+1)
	{
		int t=*s2.begin();
		s1.insert(t);
		s2.erase(s2.begin());
	}
}
int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	/*
	s1.insert(1);
	s1.insert(2);
	cout<<*s1.begin()<<endl;
	*/
	
	int n,op,x;
	scanf("%d",&n);
	while (n--)
	{
		scanf("%d",&op);
		if (op==1)
		{
			scanf("%d",&x);
			q.push(x);
			if (x>*s2.begin())
			{
				s2.insert(x);
			}
			else if (x<*s1.begin())
			{
				s1.insert(x);
			}
			else
			{
				if (s1.size()>=s2.size())
				{
					s2.insert(x);
				}
				else
				{
					s1.insert(x);
				}
			}
			adjust();
		}
		else if (op==2)
		{
			int t=q.front();
			q.pop();
			if (s1.find(t)!=s1.end())
			{
				s1.erase(t);
			}
			else
			{
				s2.erase(t);
			}
			adjust();
		}
		else 
		{
			if (s1.size()>s2.size())
			{
				printf("%d\n",*s1.begin());
			}
			else
			{
				printf("%d\n",*s2.begin());
			}
		}
	}
}
