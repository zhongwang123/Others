#include<bits/stdc++.h>

#define clr(x,y) memset((x),(y),sizeof(x))

using namespace std;
typedef long long LL;

const int inf=1e6;
const int maxn=1<<18;

int dp[maxn+5];

inline bool check(int x,int i,int j,int k)
{
    return ((x&(1<<i)) && (x&(1<<j)) && (x&(1<<k)));
}

inline int f(int x,int y)
{
    int res=0;

    int y2=y/3*3+(y%3+1)%3;
    int y3=y/3*3+(y%3+2)%3;
    if ((x&(1<<y2)) && (x&(1<<y3))) ++res;

    int tmp=x|(1<<y);
    if ((!check(x,2,4,6)) && check(tmp,2,4,6)) ++res;
    if ((!check(x,5,10,12)) && check(tmp,5,10,12)) ++res;
    if ((!check(x,8,13,15)) && check(tmp,8,13,15)) ++res;

    return res;
}

int solve(int x)
{
    if (dp[x]!=-inf) return dp[x];
    if (x==(1<<18)-1) return dp[x]=0;
    for (int i=0;i<=17;++i)
    {
        if (x&(1<<i)) continue;
        int ans=f(x,i);
        if (ans>0)
            dp[x]=max(dp[x],ans+solve(x|(1<<i)));
        else
        {
            dp[x]=max(dp[x],-solve(x|(1<<i)));
        }
    }
    return dp[x];
}

int main(void)
{
	#ifdef ex
	freopen ("../in.txt","r",stdin);
	//freopen ("../out.txt","w",stdout);
	#endif

	fill (dp,dp+sizeof(dp)/sizeof(int),-inf);
	int n;
	scanf("%d",&n);
	int k=0;
	int x=0;
	for (int i=1;i<=n;++i)
    {
        scanf("%d",&x);
        --x;
        k=k|(1<<x);
    }
    int ans=solve(k);

    if (ans>0) printf("WIN!\n");
    else if (ans<0) printf("LOSE!\n");
    else printf("Draw\n");
}
