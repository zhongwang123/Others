#include<bits/stdc++.h>

using namespace std;
typedef long long LL;

const int maxn=1e5;

int Next[maxn+5];
char pattern[maxn+5];
char text[maxn+5];
int pos[maxn+5];

void init_Next(char pattern[])
{
	int n=strlen(pattern);
	memset(Next,0,sizeof(Next));
	
	for (int i=1;i<n;++i)
	{
		int j=i;
		while (j>0)
		{
			j=Next[j];
			if (pattern[j]==pattern[i])
			{
				Next[i+1]=j+1;
				break;
			}
		}
	}
}

void KMP(char pattern[],char text[])
{	
	int m=strlen(text);
	int n=strlen(pattern);
	
	init_Next(pattern);
	memset(pos,0,sizeof(pos));
	
	for (int i=0,j=0;i<m;++i)
	{
		if (j<n && text[i]==pattern[j])
		{
			++j;
		}
		else
		{
			while (j>0)
			{
				j=Next[j];
				if (text[i]==pattern[j])
				{
					++j;
					break;
				}
			}
		}
		
		if (j==n) 
		{
			pos[i-n+1]=1;
		}
	}
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	//freopen ("out.txt","w",stdout);
	#endif
	
	scanf("%s%s",text,pattern);
	
	KMP(pattern,text);
	int n=strlen(text);
	int m=strlen(pattern);
	
	int ans=0;
	for (int i=0;i<=n-1;++i)
	{
		if (pos[i]==1)
		{
			++ans;
			i=i+m-1;
		}
	}
	printf("%d\n",ans);
	
}
