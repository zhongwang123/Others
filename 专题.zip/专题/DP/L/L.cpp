#include<bits/stdc++.h>

using namespace std;
typedef long long LL;
typedef struct S S;

const int maxn=1e5;

struct S
{
	int x,v,y;
};

int id[maxn+5];
int point[maxn+5];
LL T[4*maxn+5];
LL dp[maxn+5];

S p[maxn+5];

int tree_size(int n)
{
	int k=1;
	while (k<n)
	{
		k<<=1;
	}
	return k;
}

LL query(int k,int cl,int cr,int l,int r)
{
	if (cl>r || cr<l) return -1;
	if (l<=cl && cr<=r)
	{
		return T[k];
	}
	
	int mid=(cl+cr)>>1;
	return max(query(k<<1,cl,mid,l,r),query((k<<1)+1,mid+1,cr,l,r));
}

void update(int k,int cl,int cr,int x,LL p)
{
	if (x<cl || x>cr) return;
	if (cl==cr && cl==x)
	{
		T[k]=max(T[k],p);
		return;
	}
	if (cl<=x && x<=cr)
	{
		int mid=(cl+cr)>>1;
		update(k<<1,cl,mid,x,p);
		update((k<<1)+1,mid+1,cr,x,p);
		T[k]=max(T[k<<1],T[(k<<1)+1]);
	}
}

bool cmp(const int &a,const int &b)
{
	if (p[a].x!=p[b].x)
	{
		return p[a].x<p[b].x;
	}
	else
	{
		return a<b;
	}
}

int main(void)
{
	#ifdef ex
	freopen ("in.txt","r",stdin);
	#endif
	
	int n;
	scanf("%d",&n);
	
	for (int i=1;i<=n;++i)
	{
		scanf("%d%d%d",&p[i].x,&p[i].v,&p[i].y);
		id[i]=i;
	}
	
	sort(id+1,id+n+1,cmp);
	
	int num=0;
	for (int i=1;i<=n;++i)
	{
		point[++num]=p[id[i]].x;
		while (p[id[i]].x==p[id[i+1]].x)
		{
			++i;
		}
	}
	
	int Tsize=tree_size(n);
	
	memset(dp,0,sizeof(dp));
	memset(T,0,sizeof(T));
	
	for (int i=1;i<=n;++i)
	{
		int r=upper_bound(point+1,point+1+num,p[i].x)-point;
		int l=lower_bound(point+1,point+1+num,p[i].x-p[i].y)-point;
		dp[i]=query(1,1,Tsize,l,r)+p[i].v;
		
		update(1,1,Tsize,r,dp[i]);
	}
	
	LL ans=0;
	for (int i=1;i<=n;++i)
	{
		ans=max(ans,dp[i]);
		//cout<<point[i]<<endl;
	}
	printf("%lld\n",ans);
}
