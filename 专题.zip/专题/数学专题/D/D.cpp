#include<bits/stdc++.h>

#define clr(x,y) memset((x),(y),sizeof(x))

using namespace std;
typedef long long LL;

int main(void)
{
	#ifdef ex
	freopen ("../in.txt","r",stdin);
	//freopen ("../out.txt","w",stdout);
	#endif

	int n,k;
	cin>>n>>k;

	if (n&1)
    {
        if (!(k&1))
            cout<<-1<<endl;
        else
        {
            int tmp=ceil(n*1.0/k);
            if (tmp&1)
                cout<<tmp<<endl;
            else cout<<tmp+1<<endl;
        }
    }
    else
    {
        if (k&1)
        {
            if (k>n/2 && k<=n-1)
            {
                int tmp=ceil(n*1.0/(n-k));
                if (tmp&1) ++tmp;
                cout<<tmp<<endl;
            }
            else if (k<=n/2)
            {
                int tmp=ceil(n*1.0/k);
                if (tmp&1) ++tmp;
                cout<<tmp<<endl;
            }
        }
        else
        {
            if (k>n/2 && k<n-1)
                cout<<3<<endl;
            else if (k<=n/2)
            {
                int tmp=ceil(n*1.0/k);
                cout<<tmp<<endl;
            }
            else if (n==k)
                cout<<1<<endl;
        }
    }
}
